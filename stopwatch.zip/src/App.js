import React, { useState, useEffect } from "react";
import "./styles.css";

export default function StopWatchApp() {
  const [time, setTime] = useState(0);
  const [isRunning, setIsRunning] = useState(false);

  useEffect(() => {
    let timerInterval;

    if (isRunning) {
      timerInterval = setInterval(() => {
        setTime((prevTime) => prevTime + 1);
      }, 1000);
    } else {
      clearInterval(timerInterval);
    }

    return () => {
      clearInterval(timerInterval);
    };
  }, [isRunning]);

  const formatTime = (time) => {
    const hours = Math.floor(time / 3600);
    const minutes = Math.floor((time % 3600) / 60);
    const seconds = time % 60;
    return `${hours.toString().padStart(2, "0")}:${minutes
      .toString()
      .padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
  };

  const handleStart = () => {
    setIsRunning(true);
  };

  const handlePause = () => {
    setIsRunning(false);
  };

  const handleReset = () => {
    setTime(0);
    setIsRunning(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center div-outside">
      <div className="rounded-md text-center div-inside-elements">
        <h1 className="heading">Stopwatch</h1>
        <div className="text-white text-4xl mb-4 div-timer bg-blue-500 rounded-lg p-4">
          <h1 className="heading-timer">Time: {formatTime(time)}</h1>
        </div>
        <div className="space-x-4">
          <button
            className="bg-blue-500 text-white px-4 py-2 rounded-md"
            onClick={handleStart}
          >
            Start
          </button>
          <button
            className="bg-yellow-500 text-white px-4 py-2 rounded-md"
            onClick={handlePause}
          >
            Pause
          </button>
          <button
            className="bg-green-500 text-white px-4 py-2 rounded-md"
            onClick={handleReset}
          >
            Reset
          </button>
        </div>
      </div>
    </div>
  );
}
